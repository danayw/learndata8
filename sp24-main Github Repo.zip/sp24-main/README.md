---
layout: page
title: ReadMe
tagline: Data 8 - Foundations of Data Science
nav_exclude: true
---

# Foundations of Data Science
{: .mb-2 }
UC Berkeley
{: .mb-0 .fs-6 .text-grey-dk-000 }

Spring 2024 offering of Data 8: Foundations of Data Science at UC Berkeley. Redesigned website by Jonathan Ferrari using Just the Docs.

View [this page](https://docs.github.com/en/pages/setting-up-a-github-pages-site-with-jekyll/testing-your-github-pages-site-locally-with-jekyll) for info on how to build locally to test.