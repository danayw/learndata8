---
email: michaelflorip@berkeley.edu
name: Michael Florip
pronouns: HE/HIM/HIS
photo: staff/michael_l.jpeg
bio: Hi! I'm Michael, a second-year Data Science major. I also hold positions as a Data Science Peer Advisor for CDSS and as a member of Data Science Society at Berkeley
role: Tutor (UCS1)
office-hours: TBA
---
