---
email: ramishakabir@berkeley.edu
name: Ramisha Kabir
pronouns: SHE/HER
photo: staff/ramisha.jpeg
bio: hey! i'm a third year studying data science and cs. data 8 was my first coding experience and it changed my world. i'm so excited you're here :) 
role: 20-hour Lead uGSI (UCS2)
office-hours: Mon 1-2PM, Tue 11-12PM
team: Scholars & Tutors
---
