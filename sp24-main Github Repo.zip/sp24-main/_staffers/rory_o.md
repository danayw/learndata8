---
email: rory_powell@berkeley.edu
name: Rory Powell
pronouns: SHE/HER
photo: staff/rory_o.jpeg
bio: Baltimore girl turned Berkeley sophomore studying Cog Sci + Legal Studies. Runs on bagels, diet coke and an infinite love for data8 :)
role: Tutor (UCS1)
office-hours: TBA
---
