---
email: aileenwu@berkeley.edu
name: Aileen Wu
pronouns: SHE/THEY
photo: staff/aileen.jpeg
bio: Hi! I'm a junior from Vancouver, BC studying data science and econ. Probably chasing snow or fun hikes when not studying. Super stoked to meet everyone!
role: uGSI (UCS2)
office-hours: Mon 11-1 PM
---
