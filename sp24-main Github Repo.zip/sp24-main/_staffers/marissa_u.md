---
email: marissa_lumpkin@berkeley.edu
name: Marissa Lumpkin
pronouns: SHE/HER
photo: staff/marissa_u.jpeg
bio: Hello!! I’m a sophomore from SF studying computer science and mechanical engineering. I like going on runs in the fire trails, designing race cars, and making art. Can’t wait for a Data gr8 semester!
role: Tutor (UCS1)
office-hours: TBA
---
