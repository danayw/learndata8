---
email: tilouie@berkeley.edu
name: Tiffany Louie
pronouns: SHE/HER
photo: staff/tiffany_o.jpeg
bio: Hello! I'm a second year from San Francisco who is studying data science. My current interests include puzzle games / escape rooms and trying public transportation at different places.
role: Tutor (UCS1)
office-hours: TBA
---
