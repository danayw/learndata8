---
email: isabelladuong@berkeley.edu
name: Isabella Duong
pronouns: SHE/HER
photo: staff/isabella_u.jpeg
bio: hey! i'm isabella and i'm a sophomore studying computer science. i like cats and data 8 ;D
role: Tutor (UCS1)
office-hours: TBA
---
