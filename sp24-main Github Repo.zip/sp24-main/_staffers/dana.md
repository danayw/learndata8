---
email: dbenedicto@berkeley.edu
name: Dana Benedicto
pronouns: SHE/HER
photo: staff/dana.jpeg
bio: super excited to be back for an awesome final semester with my favorite class on campus <3
role: 20-hour Lead uGSI (UCS2)
office-hours: Thu 2-3PM, Fri 11-12PM
team: Extensions
---
