---
email: brandonsu@berkeley.edu
name: Brandon Su
pronouns: HE/HIM
photo: staff/brandon_s.jpeg
bio: Hi! I'm a sophomore from the Bay studying Applied Math and CS. I love teaching, nature, and recently been obsessed with honey 🍯
role: uGSI (UCS2)
office-hours: Mon 1-2PM
---
