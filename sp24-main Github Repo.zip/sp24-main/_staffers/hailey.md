---
email: haileyholcomb@berkeley.edu
name: Hailey Holcomb 
pronouns: SHE/HER
photo: staff/hailey.jpeg
bio: Hi! I’m a third year studying Data Science and Industrial Engineering & Operations Research, and this is my 6th semester on Data 8 staff. Talk to me about plants, music, crafts, and Tetris
role: uGSI (UCS2)
office-hours: Tue 1-3PM
---
