---
email: conan.smallwood@berkeley.edu
name: Conan Smallwood
pronouns: HE/HIM
photo: staff/conan.jpeg
bio: Hey everyone! I’m a junior from Japan studying Statistics and Data Science who loves playing tennis, ping pong, rocket league, and drinking coffee!
role: uGSI (UCS2)
office-hours: Fri 1-2PM
---
