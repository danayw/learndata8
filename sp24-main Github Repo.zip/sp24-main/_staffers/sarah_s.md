---
email: sasong@berkeley.edu
name: Sarah Song
pronouns: SHE/HER
photo: staff/sarah_s.jpeg
bio: Hi! I’m a fourth year from Iowa studying DS + Statistics, and I adore cats, eating, and romping around town 😄
role: 20-hour Lead uGSI (UCS2)
office-hours: Tue 12-2PM
team: Course Director
---
