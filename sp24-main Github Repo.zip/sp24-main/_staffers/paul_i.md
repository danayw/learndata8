---
email: paulsimoncastro@berkeley.edu
name: Paul Simon Castro
pronouns: HE/HIM/HIS
photo: staff/paul_i.jpeg
bio: A senior transfer from SoCal majoring in Applied Math who's a huge Pokémon & Studio Ghibli fan. I'm super excited to begin the new year with another semester of Data 8! 
role: Tutor (UCS1)
office-hours: TBA
---
