---
email: sadibnia@berkeley.edu
name: Sahand Adibnia
pronouns: HE/HIM
photo: staff/sahand.jpeg
bio: Hi everyone! I'm Sahand, a second year from the Bay studying chemistry and data science. I'm a big fan of soccer, cats, cars, and of course Data 8!
role: uGSI (UCS2)
office-hours: Wed 2-3PM
---
