---
email: biancarein@berkeley.edu
name: Bianca Del Rosario
pronouns: SHE/HER
photo: staff/bianca.jpeg
website: https://www.linkedin.com/in/biancarein/
bio: senior that's developing a new york times games addiction, loves dilly dallying and in constant need of a morning bev
role: uGSI (UCS2)
office-hours: Wed 12-1PM
---
