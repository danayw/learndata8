---
email: aaathreya@berkeley.edu
name: Anousha Athreya
pronouns: SHE/HER
photo: staff/anousha.jpeg
bio: hey everyone! i'm anousha and i'm a second year studying eecs. i'm a fan of mystery movies and detective shows so let me know if you have any recs!
role: Tutor (UCS1)
office-hours: TBA
---
