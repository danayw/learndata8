---
email: azalea.mbailey@berkeley.edu
name: Azalea Bailey
pronouns: SHE/HER
photo: staff/azalea_a.jpeg
bio: Hi everyone!! I’m a sophomore from Upstate NY studying Computer Science. In my free time I like to learn new instruments, explore hiking trails, and play card games.
role: Tutor (UCS1)
office-hours: TBA
---
