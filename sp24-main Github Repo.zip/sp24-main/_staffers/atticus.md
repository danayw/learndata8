---
email: atticus.ginsborg@berkeley.edu
name: Atticus Ginsborg
pronouns: HE/HIM
photo: staff/atticus.jpeg
bio: Hi everyone! I’m a Senior studying Data Science and Economics. Outside of school I love watching and playing all sports (especially chess), reading, and going on hikes in the Berkeley hills.
role: 20-hour Lead uGSI (UCS2)
office-hours: Tue 11-1PM
team: Logistics
---
