---
email: jonathanferrari@berkeley.edu
name: Jonathan Ferrari
pronouns: HE/THEY
photo: staff/jonathan.jpeg
website: https://jonathanferrari.com
bio: hi! i’m a senior majoring in DS, CogSci, Psych, and minor in CS. when im not teaching or in class, you can usually find me at a cafe around campus, playing zelda/smash bros with friends, or out at a nearby hiking trail! a fun fact about me is that i’ve been to 47 states and 2/3 of the national parks!
role: 20-hour Lead uGSI (UCS2)
office-hours: Tue 3-4PM, Fri 12-1PM
team: Content
---
