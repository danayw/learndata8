---
email: jedwin321@berkeley.edu
name: Edwin Vargas Navarro
pronouns: HE/HIM
photo: staff/edwin.jpeg
bio: Hey y'all! I’m a junior majoring in Data Science and minoring in CalTeach. I enjoy going on runs, biking, and playing video games with friends.
role: 20-hour Lead uGSI (UCS2)
office-hours: Wed 3-4PM (online), Thu 12-1PM
team: Content
---
