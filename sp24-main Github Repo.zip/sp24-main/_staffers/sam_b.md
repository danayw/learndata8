---
email: samuelbobick@berkeley.edu
name: Sam Bobick
pronouns: HE/HIM
photo: staff/samuel.jpeg
bio: Hi! I’m a third year studying computer science. I’m a big fan of coffee, chocolate milk, and fruit smoothies.
role: 20-hour Lead uGSI (UCS2)
office-hours: Tue 3-4PM, Thu 2-3PM
team: Grading
---
