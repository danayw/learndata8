---
email: kaedesposo@berkeley.edu
name: Kaed Esposo
pronouns: HE/HIM
photo: staff/kaed.jpeg
bio: Hey everyone, I’m a junior from Hawaii majoring in Data Science and Political Science. During my free time you can find me either at a concert, thrifting, or hanging with friends.
role: uGSI (UCS2)
office-hours: Wed 11-12PM
---
