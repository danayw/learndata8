---
email: dylan.tay@berkeley.edu
name: Dylan Tay
pronouns: HE/HIM
photo: staff/dylan_a.jpeg
bio: Hi friends! Some things I love are making little cakes, badminton in the RSF and Lego City. Thank you for being a part of my Data 8 experience and I know we'll do great together :)
role: Tutor (UCS1)
office-hours: TBA
---
