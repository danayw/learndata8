---
email: zachmackin@berkeley.edu
name: Zach Mackin
pronouns: HE/HIM
photo: staff/zachary.jpeg
bio: My name is Zach Mackin, I am a Senior studying Computer Science and Statistics, and am from Denver, Colorado. In my free time I enjoy hiking, watching college sports, disc golfing, reading, and traveling.
role: uGSI (UCS2)
office-hours: Fri 11-1PM
---
