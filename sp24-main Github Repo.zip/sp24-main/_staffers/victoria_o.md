---
email: victoriama@berkeley.edu
name: Victoria Mouro Assahina
pronouns: SHE/HER
photo: staff/victoria_o.jpeg
bio: Hi everyone! I'm Vic/Vicky/VV, I'm a second-year majoring in Econ + DS. I love cats, cooking/baking and old music hehe. Super excited to be on staff this semester!!
role: Tutor (UCS1)
office-hours: TBA
---
