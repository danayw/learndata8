---
email: brandon_concepcion@berkeley.edu
name: Bing Concepcion
pronouns: HE/HIM
photo: staff/bing_o.jpeg
website: https://www.youtube.com/watch?v=dQw4w9WgXcQ&ab_channel=RickAstley 
bio: Hi! I'm a sophomore from the bay area studying Data Science and CS. I enjoy hikes, k-pop, going to the gym, and walking my dogs 🐶. Looking forward to a great semester :) 
role: Tutor (UCS1)
office-hours: TBA
---
