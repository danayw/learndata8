---
email: samanthacenteno@berkeley.edu
name: Sam Centeno
pronouns: SHE/HER
photo: staff/sam.jpeg
bio: Hi everyone! I’m Sam, a 3rd year CS+DS major who loves sushi, Summer Walker and Data 8 <33 Beyond excited to meet all of you this semester!!
role: uGSI (UCS2)
office-hours: Wed 12-1PM
---
