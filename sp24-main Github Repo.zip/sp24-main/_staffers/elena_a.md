---
email: elena.lagrange@berkeley.edu
name: Elena Lagrange
pronouns: SHE/HER
photo: staff/elena_a.jpeg
bio: Hi everyone, I'm a junior from the bay area double majoring in Economics and Data Science. I love traveling, R&B music, sunsets, exploring new bookstores or restaurants, and I'm a big cappuccino enthusiast :)
role: Tutor (UCS1)
office-hours: TBA
---
