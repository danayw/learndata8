---
email: wtgerken@berkeley.edu
name: Thomas Gerken
pronouns: HE/HIM
photo: staff/thomas.jpeg
bio: Hi everyone, I'm so excited to be returning as a 3rd time GSI to the best staff on campus! I'm a double major in Data Science and Economics, and I'm looking forward to getting to know you all this semester.
role: 20-hour Lead uGSI (UCS2)
office-hours: Mon 12-2PM
team: Scholars & Tutors
---
