---
email: jhamada@berkeley.edu
name: Jackson Hamada
pronouns: HE/HIM
photo: staff/jackson_a.jpeg
bio: My name is Jackson and I'm a third year Data Science Major with an Applied Math concentration.
role: Tutor (UCS1)
office-hours: TBA
---
