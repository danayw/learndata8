---
email: gamyaguas@berkeley.edu
name: Gamy Aguas
pronouns: HE/HIM
photo: staff/gamy.jpeg
bio: Helloooo hellooo :D ! The name is Gamy and I am from Escondido CA, majoring math and CS! I am a HUGE fan of music (obsessed with kpop atm), coffee, minecraft and pokemon(dratini <3).  
role: 20-hour Lead uGSI (UCS2)
office-hours: Thu 11-12PM, Fri 1-2PM
team: Logistics
---
