---
email: capibarra@berkeley.edu
name: Cai Ibarra
pronouns: SHE/HER
photo: staff/cai.jpeg
bio: Hi! I’m a junior from Manila majoring in DS & MCB (triple major in eating sushi & drinking matcha). Excited to meet everyone!
role: uGSI (UCS2)
office-hours: Wed 3-4PM
---
