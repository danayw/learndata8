---
email: ljs233233@berkeley.edu
name: Jinsheng Li
pronouns: HE/HIM/HIS
photo: staff/jinsheng_i.jpeg
bio: Hey everyone! I'm Jinsheng, a second year physics major and classics minor. I grew up in Beijing, China, and spent much of my life in Fort Worth, Texas. Come and talk to me about Taylor Swift, J-pop, video games, places to visit in the SF Bay, or anything you like! Can't wait for a great semester of Data 8!
role: Tutor (UCS1)
office-hours: TBA
---
