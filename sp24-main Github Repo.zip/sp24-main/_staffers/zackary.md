---
email: zackaryoon134@berkeley.edu
name: Zackary Oon
pronouns: HE/HIM
photo: staff/zackary.jpeg
bio: Hey there, I'm Zack, a 3rd year studying CS and DS, and I'm super excited to be returning to course staff! On my free time I enjoy playing super smash bros and pokemon showdown :^)
role: 20-hour Lead uGSI (UCS2)
office-hours: Tue 2-4 PM
team: Pedagogy
---
