---
email: noah.s.tran@berkeley.edu
name: Noah Tran
pronouns: HE/HIM
photo: staff/noah.jpeg
bio: Hi everyone, nice to meet you! I'm a big fan of crosswords, taking naps, and Data 8.
role: 20-hour Lead uGSI (UCS2)
office-hours: Wed 12-2PM
team: Course Director
---
