---
email: kelseyley@berkeley.edu
name: Kelsey Ley
pronouns: SHE/HER
photo: staff/kelsey.jpeg
bio: Well-adjusted senior data science major with a slight addiction to mobile games.
role: 20-hour Lead uGSI (UCS2)
office-hours: Tue 1-3PM
team: Grading
---
