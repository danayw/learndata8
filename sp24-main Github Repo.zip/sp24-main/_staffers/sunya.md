---
email: sunya@berkeley.edu
name: Sunya Abbasi
pronouns: SHE/HER
photo: staff/sunya.jpeg
bio: Hi! I'm a senior from the Bay studying Data Science and Demography. 
role: uGSI (UCS2)
office-hours: Wed 1-2PM, 2-3PM (online)
---
