---
email: arfamomin@berkeley.edu
name: Arfa Momin
pronouns: SHE/HER
photo: staff/arfa_o.jpeg
bio: Hi y’all! I’m a sophomore from Texas studying Geography and CS. Some things I enjoy are art, cool maps, matcha lattes, and messing around on Google Earth.
role: Tutor (UCS1)
office-hours: TBA
---
