---
email: dagnystreit@berkeley.edu
name: Dagny Streit
pronouns: SHE/HER
photo: staff/dagny_t.jpeg
bio: Hi! I’m Dagny, a sophomore from Orange County, California, studying applied mathematics and computer science. Outside of class, I enjoy baking, reading, gardening, and traveling!
role: Tutor (UCS1)
office-hours: TBA
---
