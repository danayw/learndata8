---
email: simone.nguyen10@berkeley.edu
name: Simone Nguyen 
pronouns: SHE/HER
photo: staff/simone_g.jpeg
bio: hi! i'm a third year from LA majoring in American Studies and minoring in Data Science. outside data 8, i'm stoked about running, overpriced coffee shops, and big thief. 
role: Tutor (UCS1)
office-hours: TBA
---
