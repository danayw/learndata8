---
email: elladeguzman@berkeley.edu
name: Ella DeGuzman
pronouns: SHE/HER
photo: staff/ella.jpeg
bio: Hi!! I’m a third year studying Computer Science and Bioengineering. Outside of school, I enjoy traveling, painting, taking film photos, and fashion!! Can't wait to meet you all.
role: uGSI (UCS2)
office-hours: Mon 11-1PM
---
