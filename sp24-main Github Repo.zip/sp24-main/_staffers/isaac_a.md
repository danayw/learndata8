---
email: isaacwang2004@berkeley.edu
name: Isaac Wang
pronouns: HE/HIM/HIS
photo: staff/isaac_a.jpeg
bio: Hi! I am a sophomore from Shanghai, China majoring in Data Science + Statistics. In my spare time I really enjoy soccer, driving, and classical music. So excited to meet everyone!
role: Tutor (UCS1)
office-hours: TBA
---
