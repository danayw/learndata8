---
name: Swupnil Sahai
pronouns: he/him
role: Instructor
email: swupnil@berkeley.edu
photo: staff/swupnil.jpeg
office-hours: Monday 4-6pm @ <a href="https://www.lib.berkeley.edu/about/fsm-cafe">FSM Café</a>
bio: <a href="https://www.linkedin.com/in/swupnil/">Swupnil</a> is a 2013 Cal grad, CEO of <a href="https://swing.tennis">SwingVision</a>, and 8-time lecturer of Data 8 🤓 Previously, he led object tracking at Tesla A.I. ⚡ If he’s not at Wheeler, you can catch him traveling, hiking or playing tennis 🎾
---
