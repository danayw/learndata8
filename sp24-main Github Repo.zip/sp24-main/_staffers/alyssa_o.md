---
email: alyssa.wong@berkeley.edu
name: Alyssa Wong
pronouns: SHE/HER
photo: staff/alyssa_o.jpeg
bio: Hi! I'm a sophomore from Arizona studying data science. I love to dance, gym, listen to music and hang with my friends.
role: Tutor (UCS1)
office-hours: TBA
---
