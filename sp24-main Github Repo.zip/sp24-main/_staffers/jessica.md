---
email: jessicagolden@berkeley.edu
name: Jessica Golden 
pronouns: SHE/HER
photo: staff/jessica.jpeg
bio: Hi, I’m a junior studying data science and cognitive science. Outside of school, I love solving puzzles, playing percussion in UCBSO, staring at squirrels, crocheting, and journaling!
role: uGSI (UCS2)
office-hours: 12-1PM
---
