---
email: ishanibasak@berkeley.edu
name: Ishani Basak
pronouns: SHE/HER
photo: staff/ishani_a.jpeg
bio: Hi! I'm a third year studying in Data Science and Applied Mathematics. Outside of academics, I love to dance and climb. Excited to meet everyone!
role: Tutor (UCS1)
office-hours: TBA
---
