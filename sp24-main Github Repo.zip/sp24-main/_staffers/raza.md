---
name: Raza Khan
pronouns: he/him
role: Instructor
email: mraza@berkeley.edu
photo: staff/raza.jpeg
office-hours: See <a href = "https://edstem.org/us/courses/52859/discussion/4144984">Ed</a> for information
bio: <a href ="https://www.linkedin.com/in/razarehman/">Raza</a> is a 2018 Cal grad. Currently, he is working as an Applied Scientist in the Amazon Music Spoken Language Understanding team and has worked at Microsoft and Google in similar roles in the past as well. This is the second time he is teaching Data 8 course. Outside of work, sketching and watching soccer matches are his favorite hobbies.
---
