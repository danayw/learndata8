---
email: ichung727@berkeley.edu
name: Isaac Chung
pronouns: HE/HIM
photo: staff/isaac_h.jpeg
bio: hi i'm isaac! i'm a sophomore trying to draw and read more this semester - let me know if you have music reccs! welcome to data 8 :D
role: Tutor (UCS1)
office-hours: TBA
---
