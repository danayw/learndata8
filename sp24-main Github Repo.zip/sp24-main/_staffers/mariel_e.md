---
email: marieltdr@berkeley.edu
name: Mariel Del Rosario
pronouns: SHE/THEY
photo: staff/mariel_e.jpeg
bio: Hi everyone! I'm a sophomore studying data science and geography. Outside of school, I love maps, boba runs, and cooking fried rice with whatever's in my fridge. So excited for this semester of Data 8!!
role: Tutor (UCS1)
office-hours: TBA
---
