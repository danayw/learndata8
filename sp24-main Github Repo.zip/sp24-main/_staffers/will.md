---
email: willy.reed13@berkeley.edu
name: Will Reed
pronouns: HE/HIM/HIS
photo: staff/will.jpeg
bio: hi y'all :) my name is will and i'm a junior studying public health and data science! outside of school, i love listening to music, eating food, and playing/watching basketball. i'm super excited to meet and work with y'all this semester!
role: uGSI (UCS2)
office-hours: Wed 11-12PM
---
