---
email: seanrezaie@berkeley.edu
name: Sean Rezaie
pronouns: HE/HIM
photo: staff/sean_e.jpeg
bio: Hi everyone - I'm Sean, a third year from SoCal studying Computer Science. I love One Piece, chess, weightlifting, and Data 8.
role: Tutor (UCS1)
office-hours: TBA
---
