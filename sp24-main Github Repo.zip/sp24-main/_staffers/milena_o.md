---
email: mnovakovic@berkeley.edu
name: Milena Novakovic
pronouns: SHE/HER
photo: staff/milena_o.jpeg
bio: Whatsup ;) im Milena, second year data sci and cog sci student. reach out if you know of any cool concerts, or just for a chat. anyways, live love data 8 
role: Tutor (UCS1)
office-hours: TBA
---
