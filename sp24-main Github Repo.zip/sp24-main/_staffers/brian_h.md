---
email: brianrw@berkeley.edu
name: Brian Whitney
pronouns: HE/HIM
photo: staff/brian_h.jpeg
bio: Hi all, I'm a sophomore studying DS and I enjoy playing the harp, badminton, and working on data science. Excited to be tutoring this semester!
role: Tutor (UCS1)
office-hours: TBA
---
