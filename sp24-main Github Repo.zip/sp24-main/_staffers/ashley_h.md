---
email: ashley.chang@berkeley.edu
name: Ashley Chang
pronouns: SHE/HER
photo: staff/ashley_h.jpeg
bio: Hi guys! I'm Ashley, a sophomore from the Bay Area studying Data Science. Excited to meet everyone!
role: Tutor (UCS1)
office-hours: TBA
---
