---
title: Week 7 Announcements
week: 7
date: 2024-02-25
---

* HW 06 due **Wednesday 2/28**
* Lab 06 due **Friday 3/1**
* Midterm: March 8th from 7:00PM - 9:00PM 