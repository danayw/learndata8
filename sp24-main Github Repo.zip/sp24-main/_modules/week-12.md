---
title: Week 12
class: Berkeley
status: Active
---

Apr 1
: **29 (Sahai)**{: .label} Correlation
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [15](https://inferentialthinking.com/chapters/15/Prediction.html), [15.1](https://inferentialthinking.com/chapters/15/1/Correlation.html)
 : Project 2 Lab Worksheet

Apr 3
: **30 (Khan)**{: .label} Linear Regression
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [15.2](https://inferentialthinking.com/chapters/15/2/Regression_Line.html)

Apr 5
: **31 (Khan)**{: .label} Least Squares
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [15.3](https://inferentialthinking.com/chapters/15/3/Method_of_Least_Squares.html), [15.4](https://inferentialthinking.com/chapters/15/4/Least_Squares_Regression.html)
: **Homework**{: .label .label-homework} Homework 10 (Due 4/10)