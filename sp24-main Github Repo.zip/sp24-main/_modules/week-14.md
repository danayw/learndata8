---
title: Week 14
class: Berkeley
status: Active
---

Apr 15
: **35 (Sahai)**{: .label} Classification
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [13](https://inferentialthinking.com/chapters/13/Estimation.html), [18](https://inferentialthinking.com/chapters/18/Updating_Predictions.html)
: Project 3 Lab Worksheet

Apr 17
: **36 (Sahai)**{: .label} Classifiers
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [17](https://inferentialthinking.com/chapters/17/Classification.html), [17.1](https://inferentialthinking.com/chapters/17/1/Nearest_Neighbors.html), [17.2](https://inferentialthinking.com/chapters/17/2/Training_and_Testing.html), [17.3](https://inferentialthinking.com/chapters/17/3/Rows_of_Tables.html)

Apr 19
: **37 (Wagner)**{: .label} Privacy
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [17.4](https://inferentialthinking.com/chapters/17/4/Implementing_the_Classifier.html)
: **Homework**{: .label .label-homework} Homework 12 (Due 4/24)