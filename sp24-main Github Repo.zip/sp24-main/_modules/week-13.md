---
title: Week 13
class: Berkeley
status: Active
---
Apr 8
: **32 (Sahai)**{: .label} Residuals
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: **Lab**{: .label .label-lab} Lab 09: Regression (Due 4/12)
 : Lab 09 Worksheet

Apr 10
: **33 (Sarah & Noah)**{: .label} Regression Inference
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [15.5](https://inferentialthinking.com/chapters/15/5/Visual_Diagnostics.html), [15.6](https://inferentialthinking.com/chapters/15/6/Numerical_Diagnostics.html)

Apr 12
: **34 (Khan)**{: .label} Updating Predictions
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [16](https://inferentialthinking.com/chapters/16/Inference_for_Regression.html)
: **Homework**{: .label .label-homework} Homework 11 (Due 4/17)
: **Project**{: .label .label-project} Project 3: Classifying Movies (Due 4/26, Checkpoint 4/21)
