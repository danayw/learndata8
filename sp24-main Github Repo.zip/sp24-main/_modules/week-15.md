---
title: Week 15
class: Berkeley
status: Active
---

Apr 22
: **38 (Sahai)**{: .label} Case Study: Tech
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: **Lab**{: .label .label-lab} Lab 10: Conditional Probability (Due 4/26)
 : Lab 10 Worksheet

Apr 24
: **39 (Adhikari)**{: .label} Inference Review
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->

Apr 26
: **40 (Sahai & Khan)**{: .label} Conclusion
: **Homework**{: .label .label-homework} Homework 13 (Due 5/5)