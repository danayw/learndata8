---
title: Week 8
class: Berkeley
status: Active
---

Mar 4
: **20 (Sahai)**{: .label} Causality
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [12.2](https://inferentialthinking.com/chapters/12/2/Causality.html)
 : Midterm Review Worksheet

Mar 6
: **21 (Khan)**{: .label} Examples
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [12.3](https://inferentialthinking.com/chapters/12/3/Deflategate.html)

Mar 8
: **22 (Khan)**{: .label} Midterm Review
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: **Exam**{: .label .label-exam} Midterm (7 - 9 PM)
