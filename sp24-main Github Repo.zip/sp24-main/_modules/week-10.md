---
title: Week 10
class: Berkeley
status: Active
---

Mar 18
: **26 (Sahai)**{: .label} The Normal Distribution
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [14.3](https://inferentialthinking.com/chapters/14/3/SD_and_the_Normal_Curve.html), [14.4](https://inferentialthinking.com/chapters/14/4/Central_Limit_Theorem.html)
: **Lab**{: .label .label-lab} Lab 08: Sample Means (Due 3/22)
 : Lab 08 Worksheet

Mar 20
: **27 (Khan)**{: .label} Sample Means
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [14.5](https://inferentialthinking.com/chapters/14/5/Variability_of_the_Sample_Mean.html)

Mar 22
: **28 (Khan)**{: .label} Designing Experiments
 <!-- : [Slides](#) &#8226; [Demos](#) &#8226; [Blank Demos](#) -->
: *Reading:* [14.6](https://inferentialthinking.com/chapters/14/6/Choosing_a_Sample_Size.html)
: **Homework**{: .label .label-homework} Homework 09 (Due 4/3)
: **Project**{: .label .label-project} Project 2: Climate (Due 4/12, Checkpoint 4/7)